﻿#include <uv.h>
#include <functional>
#include <memory>
#include <string>
#include <iostream>
#include <queue>
#include <vector>
#include <chrono>


#include <uv.h>
#include <functional>
#include <memory>
#include <string>
#include <iostream>

// 前置声明
class TcpAcceptor;
class TcpConnector;

// 通用回调类型定义
using NewConnectionCallback = std::function<void(uv_tcp_t*)>;
using ConnectCallback = std::function<void(int , uv_tcp_t* )>;
using ReadCallback = std::function<void(ssize_t, const uv_buf_t*)>;

//==================== TcpAcceptor ====================//
class TcpAcceptor {
public:
  explicit TcpAcceptor(uv_loop_t* loop) : loop_(loop) {
    uv_tcp_init(loop_, &server_);
    server_.data = this;
  }

  bool listen(const std::string& host, int port, NewConnectionCallback callback) {
    sockaddr_in addr;
    uv_ip4_addr(host.c_str(), port, &addr);

    if (uv_tcp_bind(&server_, (const sockaddr*)&addr, 0)) {
      return false;
    }

    onNewConnection_ = callback;
    return uv_listen((uv_stream_t*)&server_, 128,
      [](uv_stream_t* server, int status) {
      static_cast<TcpAcceptor*>(server->data)->handleNewConnection(status);
    }) == 0;
  }

private:
  void handleNewConnection(int status) {
    if (status < 0) return;

    uv_tcp_t* client = new uv_tcp_t;
    uv_tcp_init(loop_, client);

    if (uv_accept((uv_stream_t*)&server_, (uv_stream_t*)client) == 0) {
      onNewConnection_(client);
    }
    else {
      uv_close((uv_handle_t*)client, [](uv_handle_t* handle) {
        delete (uv_tcp_t*)handle;
      });
    }
  }

  uv_loop_t* loop_;
  uv_tcp_t server_;
  NewConnectionCallback onNewConnection_;
};

//==================== TcpConnector ====================//
class TcpConnector {
public:
  explicit TcpConnector(uv_loop_t* loop) : loop_(loop) {}

  void connect(const std::string& host, int port, ConnectCallback callback) {
    uv_tcp_t* socket = new uv_tcp_t;
    uv_tcp_init(loop_, socket);
    socket->data = this;

    sockaddr_in addr;
    uv_ip4_addr(host.c_str(), port, &addr);

    connectReq_.data = new ConnectContext{ callback, socket };
    uv_tcp_connect(&connectReq_, socket, (const sockaddr*)&addr,
      [](uv_connect_t* req, int status) {
      auto ctx = static_cast<ConnectContext*>(req->data);
      ctx->callback(status, ctx->socket);
      //delete ctx;
    });
  }

private:
  struct ConnectContext {
    ConnectCallback callback;
    uv_tcp_t* socket;
  };

  uv_loop_t* loop_;
  uv_connect_t connectReq_;
};





// 连接状态枚举
enum class ConnectionState {
  DISCONNECTED,
  CONNECTING,
  CONNECTED,
  DISCONNECTING
};

// 协议解析器基类
class ProtocolParser {
public:
  virtual ~ProtocolParser() = default;
  virtual void feed(const char* data, size_t len) = 0;
  virtual bool nextMessage(std::string& msg) = 0;
};

// 简单文本协议解析器（换行符分隔）
class LineProtocolParser : public ProtocolParser {
public:
  void feed(const char* data, size_t len) override {
    buffer_.append(data, len);
  }

  bool nextMessage(std::string& msg) override {
    size_t pos = buffer_.find('\n');
    if (pos != std::string::npos) {
      msg = buffer_.substr(0, pos);
      buffer_.erase(0, pos + 1);
      return true;
    }
    return false;
  }

private:
  std::string buffer_;
};

//==================== 增强版TcpConnection ====================//
class TcpConnection {
public:
  using ErrorCallback = std::function<void(int)>;
  using StateChangeCallback = std::function<void(ConnectionState)>;
  using MessageCallback = std::function<void(const std::string&)>;

  TcpConnection(uv_loop_t* loop, uv_tcp_t* socket)
    : loop_(loop), socket_(socket),
    state_(ConnectionState::CONNECTED),
    parser_(new LineProtocolParser())
  {
    socket_->data = this;
    startReading();
    startHeartbeat();
  }

  ~TcpConnection() {
    close();
  }

  void send(const std::string& message) {
    if (state_ != ConnectionState::CONNECTED) return;

    // 流量控制：当写队列超过阈值时暂停发送
    if (writeQueue_.size() > MAX_WRITE_QUEUE_SIZE) {
      handleError(UV_EBUSY);
      return;
    }

    writeQueue_.push(message);
    processWriteQueue();
  }

  void close() {
    if (state_ == ConnectionState::DISCONNECTED) return;
    //uv_timer_stop(heartbeatTimer_);
    uv_timer_stop(timeoutTimer_);
    state_ = ConnectionState::DISCONNECTING;
    uv_close((uv_handle_t*)socket_, [](uv_handle_t* handle) {
      auto conn = static_cast<TcpConnection*>(handle->data);
      conn->updateState(ConnectionState::DISCONNECTED);
      delete handle;
    });
  }

  ConnectionState state() { return state_; };
  // 设置各种回调
  void setErrorCallback(ErrorCallback cb) { errorCb_ = cb; }
  void setStateChangeCallback(StateChangeCallback cb) { stateChangeCb_ = cb; }
  void setMessageCallback(MessageCallback cb) { messageCb_ = cb; }

private:
  void startReading() {
    uv_read_start((uv_stream_t*)socket_,
      [](uv_handle_t*, size_t size, uv_buf_t* buf) {
      *buf = uv_buf_init(new char[size], size);
    },
      [](uv_stream_t* stream, ssize_t nread, const uv_buf_t* buf) {
      auto conn = static_cast<TcpConnection*>(stream->data);
      conn->handleRead(nread, buf);
    });
  }

  void handleRead(ssize_t nread, const uv_buf_t* buf) {
    if (nread < 0) {
      handleError(nread);
      delete[] buf->base;
      return;
    }

    // 重置心跳超时
    resetHeartbeat();

    // 协议解析
    parser_->feed(buf->base, nread);
    std::string msg;
    while (parser_->nextMessage(msg)) {
      if (messageCb_) messageCb_(msg);
    }

    delete[] buf->base;
  }

  void processWriteQueue() {
    if (writing_ || writeQueue_.empty()) return;

    writing_ = true;
    auto& msg = writeQueue_.front();
    uv_buf_t buffer = uv_buf_init(const_cast<char*>(msg.data()), msg.size());

    uv_write_t* req = new uv_write_t;
    req->data = this;

    uv_write(req, (uv_stream_t*)socket_, &buffer, 1, [](uv_write_t* req, int status) {
      auto conn = static_cast<TcpConnection*>(req->data);
      conn->handleWriteComplete(status);
      delete req;
    });
  }

  void handleWriteComplete(int status) {
    writing_ = false;
    if (status != 0) {
      handleError(status);
      return;
    }

    writeQueue_.pop();
    processWriteQueue();
  }

  void startHeartbeat() {
    heartbeatTimer_ = new uv_timer_t;
    uv_timer_init(loop_, heartbeatTimer_);
    heartbeatTimer_->data = this;

    uv_timer_start(heartbeatTimer_, [](uv_timer_t* handle) {
      auto conn = static_cast<TcpConnection*>(handle->data);
      conn->sendHeartbeat();
    }, HEARTBEAT_INTERVAL, HEARTBEAT_INTERVAL);

    // 启动超时检测
    startTimeoutCheck();
  }

  void sendHeartbeat() {
    if (state_ != ConnectionState::CONNECTED)
    {
      
      return;
    }
    send("HEARTBEAT\n");
  }

  void startTimeoutCheck() {
    timeoutTimer_ = new uv_timer_t;
    uv_timer_init(loop_, timeoutTimer_);
    timeoutTimer_->data = this;

    uv_timer_start(timeoutTimer_, [](uv_timer_t* handle) {
      auto conn = static_cast<TcpConnection*>(handle->data);
      conn->handleTimeout();
    }, TIMEOUT_DURATION, TIMEOUT_DURATION);
  }

  void resetHeartbeat() {
    uv_timer_again(timeoutTimer_);
  }

  void handleTimeout() {
    handleError(UV_ETIMEDOUT);
    close();
  }

  void handleError(int err) {
    if (errorCb_) errorCb_(err);
    close();
  }

  void updateState(ConnectionState newState) {
    state_ = newState;
    if (stateChangeCb_) stateChangeCb_(newState);
  }

  // 常量定义
  static constexpr int MAX_WRITE_QUEUE_SIZE = 1024 * 1024; // 1MB
  static constexpr unsigned int HEARTBEAT_INTERVAL = 5000; // 5秒
  static constexpr unsigned int TIMEOUT_DURATION = 15000;  // 15秒

  uv_loop_t* loop_;
  uv_tcp_t* socket_;
  ConnectionState state_;
  std::queue<std::string> writeQueue_;
  bool writing_ = false;
  std::unique_ptr<ProtocolParser> parser_;

  uv_timer_t* heartbeatTimer_ = nullptr;
  uv_timer_t* timeoutTimer_ = nullptr;

  ErrorCallback errorCb_;
  StateChangeCallback stateChangeCb_;
  MessageCallback messageCb_;
};

//==================== 增强版TcpServer ====================//
class TcpServer {
public:
  TcpServer(uv_loop_t* loop) : loop_(loop), acceptor_(loop) {
    acceptor_.listen("127.0.0.1", 8080, [this](uv_tcp_t* client) {
      handleNewConnection(client);
    });
  }

private:
  void handleNewConnection(uv_tcp_t* client) {
    auto conn = std::make_shared<TcpConnection>(loop_, client);

    conn->setErrorCallback([this, conn](int err) {
      handleConnectionError(conn, err);
    });

    conn->setMessageCallback([this](const std::string& msg) {
      std::cout << "Received message: " << msg << std::endl;
    });

    conn->setStateChangeCallback([this](ConnectionState state) {
      if (state == ConnectionState::DISCONNECTED) {
        cleanupConnection();
      }
    });

    connections_.push_back(conn);
  }

  void handleConnectionError(std::shared_ptr<TcpConnection> conn, int err) {
    std::cerr << "Connection error: " << uv_err_name(err) << std::endl;
    conn->close();
  }

  void cleanupConnection() {
    auto it = std::remove_if(connections_.begin(), connections_.end(),
      [](const std::shared_ptr<TcpConnection>& conn) {
      return conn->state() == ConnectionState::DISCONNECTED;
    });
    connections_.erase(it, connections_.end());
  }

  uv_loop_t* loop_;
  TcpAcceptor acceptor_;
  std::vector<std::shared_ptr<TcpConnection>> connections_;
};

//==================== 增强版TcpClient ====================//
class TcpClient {
public:
  TcpClient(uv_loop_t* loop) : loop_(loop), connector_(loop) {}

  void connect(const std::string& server, int port) {
    connector_.connect(server, port, [this](int status, uv_tcp_t* socket) {
      if (status == 0) {
        connection_ = std::make_shared<TcpConnection>(loop_, socket);
        connection_->send("ddd");
        setupCallbacks();
      }
      else {
        std::cerr << "Connect failed: " << uv_err_name(status) << std::endl;
      }
    });
  }

private:
  void setupCallbacks() {
    connection_->setErrorCallback([this](int err) {
      std::cerr << "Connection error: " << uv_err_name(err) << std::endl;
    });

    connection_->setStateChangeCallback([this](ConnectionState state) {
      std::cout << "Connection state changed to: "
        << static_cast<int>(state) << std::endl;
    });

    connection_->setMessageCallback([this](const std::string& msg) {
      std::cout << "Received: " << msg << std::endl;
    });
  }

  uv_loop_t* loop_;
  TcpConnector connector_;
  std::shared_ptr<TcpConnection> connection_;
};



int main() {
  uv_loop_t* loop = uv_default_loop();

  // 启动服务器
  //TcpServer server(loop);

  // 启动客户端
  TcpClient client(loop);
  client.connect("127.0.0.1", 8080);
  
  // 定时发送数据
  uv_timer_t timer;
  uv_timer_init(loop, &timer);
  uv_timer_start(&timer, [](uv_timer_t* timer) {
    static int count = 0;
    std::string msg = "Message " + std::to_string(++count) + "\n";
    // 实际应用中需要通过connection对象发送
  }, 1000, 1000);

  return uv_run(loop, UV_RUN_DEFAULT);
}